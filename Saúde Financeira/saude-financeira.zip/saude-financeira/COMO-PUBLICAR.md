# Saúde Financeira — como colocar no ar e instalar nos celulares

Este é um **PWA**: um aplicativo web que, depois de publicado em um endereço HTTPS,
se instala na tela inicial do iPhone e do Android e abre em tela cheia, sem barra
de navegador, funcionando inclusive sem internet.

São três etapas. A primeira é obrigatória; a terceira só é necessária para que os
dois celulares enxerguem os mesmos dados.

---

## Etapa 1 — Publicar a pasta (5 minutos, sem custo)

O aplicativo é um conjunto de arquivos estáticos. Qualquer hospedagem de site
estático serve. Escolha **uma** das opções abaixo.

Antes de tudo: **descompacte** o `saude-financeira.zip`. Você vai ficar com uma
pasta chamada `saude-financeira` contendo `index.html`, `styles.css`, `sw.js`,
`manifest.webmanifest` e as pastas `js/` e `icons/`. É essa pasta que sobe.

### Opção A — Cloudflare Pages (recomendada)

Gratuita, sem cartão, e o endereço já nasce público em HTTPS.

1. Acesse **https://dash.cloudflare.com/sign-up** e crie a conta (confirme o e-mail).
2. No menu lateral, vá em **Compute (Workers & Pages) → Create → Pages →
   Upload assets**.
3. Dê um nome ao projeto, por exemplo `financas-aguiar`.
4. Arraste a pasta `saude-financeira` inteira para a área de upload e clique em
   **Deploy site**.
5. O endereço sai como **`https://financas-aguiar.pages.dev`**. Guarde-o.

Para publicar uma versão nova depois: mesmo projeto → **Create new deployment** →
arraste a pasta de novo.

*Limites do upload pelo painel: 1.000 arquivos e 25 MB por arquivo — o app tem 22
arquivos e menos de 100 KB no total.*

### Opção B — Netlify Drop

Também gratuita, porém **desde julho de 2026 os projetos novos nascem privados**:
o endereço vem protegido por senha e não abre no celular da sua esposa até você
mudar isso.

1. Crie a conta em **https://app.netlify.com/signup**.
2. Acesse **https://app.netlify.com/drop** já logado e arraste a pasta.
3. **Passo obrigatório:** abra o projeto → *Project configuration → General →
   Project visibility* e mude para **público**. Sem isso, o app pede senha.
4. Em *Project configuration → Change site name*, troque para algo memorável.

### Opção C — GitHub Pages

1. Crie um repositório **público** no GitHub e envie o conteúdo da pasta.
2. Em *Settings → Pages*, selecione a branch `main` e a pasta `/ (root)`.
3. O endereço sai como `https://seu-usuario.github.io/nome-do-repo/`.

> Repositório público significa que o **código** fica visível — o que não é
> problema, porque não há nenhuma senha nem dado seu dentro dele. Seus lançamentos
> ficam no celular e na sua conta do Supabase, nunca no código.

> **Importante:** o endereço precisa ser **https**. Abrir o `index.html` direto do
> computador (`file://`) não funciona — o navegador bloqueia módulos e o modo
> aplicativo.

---

## Etapa 2 — Instalar no celular

Abra o endereço publicado no celular e siga o passo do seu aparelho.

### iPhone / iPad (obrigatoriamente pelo Safari)

1. Abra o endereço no **Safari** (não funciona pelo Chrome no iOS).
2. Toque no botão **Compartilhar** (quadrado com seta para cima).
3. Role e escolha **Adicionar à Tela de Início**.
4. Confirme o nome (“Finanças”) e toque em **Adicionar**.

### Android

1. Abra o endereço no **Chrome**.
2. Toque no menu **⋮** e escolha **Instalar aplicativo** (ou *Adicionar à tela inicial*).
3. Confirme.

Depois de instalado, o ícone fica junto dos outros aplicativos e abre em tela
cheia. Faça isso nos dois celulares.

---

## Etapa 3 — Sincronizar os dois celulares (opcional, mas é o que junta as contas)

Sem esta etapa, cada aparelho guarda seus próprios dados. Com ela, o que você
lança aparece no celular da sua esposa e vice-versa.

Usamos o **Supabase**, que tem plano gratuito muito acima do que uma família
consome.

### 3.1 Criar o projeto

1. Acesse **https://supabase.com** e crie uma conta gratuita.
2. *New project* → dê um nome (ex.: `financas-familia`), escolha a região
   **South America (São Paulo)** e defina a senha do banco (guarde-a).
3. Aguarde o projeto subir (1 a 2 minutos).

### 3.2 Criar a tabela

No menu lateral, abra **SQL Editor → New query**, cole o script abaixo e clique
em **Run**:

```sql
create table if not exists public.sf_registros (
  id            text primary key,
  tipo          text not null,
  dados         jsonb not null,
  atualizado_em timestamptz not null default now(),
  dono          uuid not null default auth.uid()
);

alter table public.sf_registros enable row level security;

create policy "dono consulta" on public.sf_registros
  for select using (auth.uid() = dono);

create policy "dono insere" on public.sf_registros
  for insert with check (auth.uid() = dono);

create policy "dono atualiza" on public.sf_registros
  for update using (auth.uid() = dono) with check (auth.uid() = dono);

create policy "dono apaga" on public.sf_registros
  for delete using (auth.uid() = dono);

create index if not exists sf_registros_atualizado_em_idx
  on public.sf_registros (atualizado_em);
```

As políticas acima garantem que **só quem está logado na conta de vocês enxerga
os dados**. Sem login, nada é lido nem gravado.

### 3.3 Desligar a confirmação de e-mail (recomendado)

Em **Authentication → Sign In / Providers → Email**, desmarque
*Confirm email* e salve. Assim vocês criam a conta do casal direto pelo app.
(Se preferir manter ligado, é só confirmar o e-mail que o Supabase enviar antes
de conectar o segundo aparelho.)

### 3.4 Pegar as credenciais

Em **Project Settings → API**, copie:

- **Project URL** — algo como `https://abcdefgh.supabase.co`
- **anon public** — a chave longa que começa com `eyJ...`

A chave `anon` é pública por natureza; a proteção real vem das políticas do
passo 3.2. **Nunca use a chave `service_role`.**

### 3.5 Conectar nos dois celulares

No aplicativo: **Mais → Sincronizar entre celulares**. Preencha:

| Campo | O que colocar |
|---|---|
| URL do projeto | o *Project URL* |
| Chave pública (anon) | a chave `anon public` |
| E-mail do casal | um e-mail que os dois vão usar (ex.: `casa@…`) |
| Senha | uma senha que os dois saibam |

Toque em **Conectar**. Na primeira vez a conta é criada; nos demais aparelhos,
use **exatamente o mesmo e-mail e senha** — é isso que junta os dados dos dois
celulares na mesma base.

A sincronização acontece sozinha ao abrir o app, ao trazê-lo para a frente e
poucos segundos depois de cada alteração. Quando dois lançamentos disputam o
mesmo registro, vale o que foi salvo por último.

### 3.6 Um detalhe do plano gratuito do Supabase

Projetos gratuitos são **pausados após cerca de 7 dias sem acesso ao banco**. Com
vocês usando o app na semana, isso não acontece. Se acontecer (viagem longa, por
exemplo), o Supabase avisa por e-mail e basta entrar no painel e clicar em
**Resume project** — os dados continuam lá, com até 1 ano para restaurar. E mesmo
com o projeto pausado o aplicativo continua funcionando normalmente em cada
celular: só a sincronização entre eles fica esperando.

---

## Como o aplicativo funciona

**Registrar** — o botão azul redondo abre o lançamento em qualquer tela. Escolha
Saída ou Entrada, digite o valor, a descrição (loja, pessoa, origem) e pronto.
Desligue *Já efetivado* para registrar como previsto (conta a pagar ou a receber).

**Recorrentes** — aluguel, escola, salário, assinaturas. Cadastre uma vez na aba
*Fixos* e o app projeta os próximos meses automaticamente. Também é possível
marcar *Repetir todo mês* na hora de lançar.

**Repetições detectadas** — quando a mesma loja ou origem aparece três vezes ou
mais em meses diferentes, o app sugere transformá-la em recorrência. Ele nunca
cria nada sozinho: a sugestão só vira recorrência quando você confirma.

**Provisão semanal** — o painel inicial mostra as próximas cinco semanas com o
que entra, o que sai e o saldo projetado ao fim de cada uma. Se alguma semana
fecha no negativo, aparece um alerta.

**Cartão de crédito** — compras no crédito não saem do caixa na data da compra.
Elas entram na fatura conforme o dia de fechamento e viram uma saída prevista na
data de vencimento. Parcelamentos se distribuem pelos meses seguintes sem perder
centavos no arredondamento.

**Orçamento** — defina um teto mensal por categoria em *Mais → Categorias*. A
barra fica laranja a partir de 85% e vermelha quando estoura.

**Fluxo de caixa** — meses passados e futuros lado a lado, com saldo acumulado
projetado, médias de três meses e sugestão de reserva de emergência.

---

## Backup e privacidade

- Os dados ficam **no aparelho** e, se a sincronização estiver ligada, na conta
  de vocês no Supabase. Ninguém mais tem acesso.
- Em *Mais → Dados*, use **Backup completo (JSON)** de tempos em tempos e guarde
  o arquivo em algum lugar seguro. **Restaurar backup** volta tudo.
- **Exportar para planilha (CSV)** gera um arquivo que abre direto no Excel e no
  Google Sheets, útil para declaração de imposto e conferências.
- Limpar os dados de navegação do celular apaga os dados locais. Com a
  sincronização ligada, é só reconectar que tudo volta.

---

## Manutenção

Para alterar qualquer coisa, edite os arquivos e publique de novo. Estrutura:

```
index.html        estrutura da página
styles.css        todo o visual (cores, tema claro/escuro, componentes)
manifest.webmanifest  identidade do app instalado
sw.js             cache offline
icons/            ícones do aplicativo
js/util.js        datas, moeda e formatação
js/finance.js     todas as regras financeiras (funções puras)
js/charts.js      gráficos em SVG, sem bibliotecas externas
js/store.js       dados, gravação local e sincronização
js/app.js         telas, formulários e navegação
testes/           testes automatizados (node testes/teste.mjs e testes/e2e.mjs)
```

Depois de publicar uma nova versão, feche e reabra o app no celular — o cache se
atualiza sozinho na abertura seguinte.
