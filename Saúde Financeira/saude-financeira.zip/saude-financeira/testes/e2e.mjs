// Teste de ponta a ponta: usa a interface como o usuário usaria.
import { chromium, devices } from 'playwright';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const RAIZ = fileURLToPath(new URL('..', import.meta.url));
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png' };
const servidor = createServer(async (req, res) => {
  try {
    let p = decodeURIComponent(req.url.split('?')[0]);
    if (p === '/') p = '/index.html';
    const arq = join(RAIZ, normalize(p));
    const dados = await readFile(arq);
    res.writeHead(200, { 'Content-Type': MIME[extname(arq)] || 'application/octet-stream' });
    res.end(dados);
  } catch { res.writeHead(404); res.end('x'); }
});
await new Promise((r) => servidor.listen(4323, r));

const navegador = await chromium.launch();
const contexto = await navegador.newContext({ ...devices['iPhone 13'], locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
const p = await contexto.newPage();
const erros = [];
p.on('pageerror', (e) => erros.push(e.message));
p.on('console', (m) => { if (m.type() === 'error') erros.push(m.text()); });

const estado = () => p.evaluate(() => JSON.parse(localStorage.getItem('sf.estado.v1')));
let ok = 0;
const t = async (nome, fn) => {
  try { await fn(); ok++; console.log('  ✓', nome); }
  catch (e) { console.error('  ✗', nome, '\n   ', e.message); process.exitCode = 1; }
};

await p.goto('http://localhost:4323/index.html');
await p.waitForTimeout(500);

console.log('\n== Fluxo do usuário ==');

await t('primeiro acesso mostra as boas-vindas', async () => {
  assert.ok(await p.locator('text=Bem-vindos').isVisible());
});

await t('define o saldo inicial', async () => {
  await p.click('[data-acao="abrir-saldo-inicial"]');
  await p.fill('#sl-valor', '5.000,00');
  await p.click('[data-acao="salvar-saldo"]');
  await p.waitForTimeout(300);
  const s = await estado();
  assert.equal(s.settings.saldoInicial, 500000);
  assert.ok(await p.locator('.hero .valor').textContent().then((x) => x.includes('5.000,00')));
});

await t('registra uma saída pelo botão flutuante', async () => {
  await p.click('.fab');
  await p.waitForTimeout(300);
  await p.fill('#tx-valor', '250,50');
  await p.fill('#tx-desc', 'Supermercado Bom Preço');
  await p.click('.opcao[data-valor="debito"]');
  await p.click('[data-acao="salvar-lancamento"]');
  await p.waitForTimeout(400);
  const s = await estado();
  const tx = s.transactions.filter((x) => !x.deleted);
  assert.equal(tx.length, 1);
  assert.equal(tx[0].valor, 25050);
  assert.equal(tx[0].metodo, 'debito');
  assert.equal(tx[0].tipo, 'saida');
  assert.equal(tx[0].pago, true);
});

await t('saldo cai depois da saída', async () => {
  const texto = await p.locator('.hero .valor').textContent();
  assert.ok(texto.includes('4.749,50'), texto);
});

await t('registra uma entrada prevista', async () => {
  await p.click('.fab');
  await p.waitForTimeout(300);
  await p.click('[data-campo="tipo"][data-valor="entrada"]');
  await p.fill('#tx-valor', '3.200,00');
  await p.fill('#tx-desc', 'Consultoria');
  await p.click('.toggle[data-campo="pago"]');
  await p.click('[data-acao="salvar-lancamento"]');
  await p.waitForTimeout(400);
  const s = await estado();
  const e = s.transactions.find((x) => x.descricao === 'Consultoria');
  assert.equal(e.tipo, 'entrada');
  assert.equal(e.pago, false);
  assert.equal(e.valor, 320000);
});

await t('valor previsto não entra no saldo realizado', async () => {
  const texto = await p.locator('.hero .valor').textContent();
  assert.ok(texto.includes('4.749,50'), texto);
});

await t('cadastra cartão e lança compra no crédito', async () => {
  await p.click('button[data-rota="mais"]');
  await p.waitForTimeout(300);
  await p.click('[data-acao="abrir-cartoes"]');
  await p.waitForTimeout(300);
  await p.click('[data-acao="novo-cartao"]');
  await p.waitForTimeout(300);
  await p.fill('#cd-nome', 'Cartão família');
  await p.fill('#cd-fech', '25');
  await p.fill('#cd-venc', '5');
  await p.click('[data-acao="salvar-cartao"]');
  await p.waitForTimeout(400);
  const s = await estado();
  assert.equal(s.cards.filter((c) => !c.deleted).length, 1);
});

await t('parcelamento gera as parcelas certas', async () => {
  await p.click('button[data-rota="inicio"]');
  await p.waitForTimeout(300);
  await p.click('.fab');
  await p.waitForTimeout(300);
  await p.fill('#tx-valor', '900,00');
  await p.fill('#tx-desc', 'Geladeira');
  await p.click('.opcao[data-valor="credito"]');
  await p.waitForTimeout(200);
  await p.selectOption('#tx-cartao', { index: 1 });
  await p.fill('#tx-parcelas', '3');
  await p.click('[data-acao="salvar-lancamento"]');
  await p.waitForTimeout(400);
  const s = await estado();
  const parc = s.transactions.filter((x) => x.descricao === 'Geladeira' && !x.deleted);
  assert.equal(parc.length, 3);
  assert.equal(parc.reduce((a, b) => a + b.valor, 0), 90000);
  assert.ok(parc.every((x) => x.metodo === 'credito' && x.cartaoId));
});

await t('cadastra recorrência e ela projeta os próximos meses', async () => {
  await p.click('button[data-rota="recorrentes"]');
  await p.waitForTimeout(300);
  await p.click('[data-acao="nova-recorrencia"]');
  await p.waitForTimeout(300);
  await p.fill('#rec-desc', 'Aluguel');
  await p.fill('#rec-valor', '2.200,00');
  await p.fill('#rec-dia', '10');
  await p.click('[data-acao="salvar-recorrencia"]');
  await p.waitForTimeout(600);
  const s = await estado();
  const rec = s.recurrences.filter((r) => !r.deleted);
  assert.equal(rec.length, 1);
  const geradas = s.transactions.filter((x) => x.recorrenciaId === rec[0].id && !x.deleted);
  assert.ok(geradas.length >= 3, `esperava 3+ projeções, veio ${geradas.length}`);
  assert.ok(geradas.every((g) => g.pago === false && g.valor === 220000));
});

await t('pausar a recorrência não apaga o que já existe', async () => {
  await p.click('.item[data-acao="editar-recorrencia"]');
  await p.waitForTimeout(300);
  await p.click('.toggle[data-campo="ativo"]');
  await p.click('[data-acao="salvar-recorrencia"]');
  await p.waitForTimeout(500);
  const s = await estado();
  assert.equal(s.recurrences.find((r) => !r.deleted).ativo, false);
});

await t('filtro de previstos funciona', async () => {
  await p.click('button[data-rota="lancamentos"]');
  await p.waitForTimeout(300);
  await p.click('.chip[data-valor="previsto"]');
  await p.waitForTimeout(300);
  const itens = await p.locator('.item').count();
  assert.ok(itens > 0);
  const efetivados = await p.locator('.item:not(.previsto)').count();
  assert.equal(efetivados, 0);
});

await t('busca filtra por descrição', async () => {
  await p.click('.chip[data-valor="todos"]');
  await p.waitForTimeout(300);
  await p.fill('[data-acao="busca"]', 'geladeira');
  await p.waitForTimeout(600);
  const textos = await p.locator('.item .t').allTextContents();
  assert.ok(textos.length > 0 && textos.every((x) => /geladeira/i.test(x)), textos.join('|'));
});

await t('edita e exclui um lançamento', async () => {
  await p.fill('[data-acao="busca"]', '');
  await p.waitForTimeout(600);
  await p.click('.chip[data-valor="efetivado"]');
  await p.waitForTimeout(300);
  await p.click('.item[data-acao="editar-lancamento"]');
  await p.waitForTimeout(300);
  await p.fill('#tx-valor', '199,90');
  await p.click('[data-acao="salvar-lancamento"]');
  await p.waitForTimeout(400);
  const s = await estado();
  assert.ok(s.transactions.some((x) => x.valor === 19990 && !x.deleted));
});

await t('cria categoria com orçamento', async () => {
  await p.click('button[data-rota="mais"]');
  await p.waitForTimeout(300);
  await p.click('[data-acao="abrir-categorias"]');
  await p.waitForTimeout(300);
  await p.click('[data-acao="nova-categoria"]');
  await p.waitForTimeout(300);
  await p.fill('#cat-nome', 'Pet');
  await p.fill('#cat-orc', '300,00');
  await p.click('[data-acao="salvar-categoria"]');
  await p.waitForTimeout(400);
  const s = await estado();
  const c = s.categories.find((x) => x.nome === 'Pet');
  assert.equal(c.orcamento, 30000);
  assert.equal(c.tipo, 'saida');
});

await t('cria meta e acompanha progresso', async () => {
  await p.click('[data-acao="abrir-metas"]');
  await p.waitForTimeout(300);
  await p.click('[data-acao="nova-meta"]');
  await p.waitForTimeout(300);
  await p.fill('#mt-nome', 'Reserva');
  await p.fill('#mt-alvo', '20.000,00');
  await p.fill('#mt-inicial', '5.000,00');
  await p.click('[data-acao="salvar-meta"]');
  await p.waitForTimeout(400);
  const s = await estado();
  const g = s.goals.find((x) => x.nome === 'Reserva');
  assert.equal(g.alvo, 2000000);
  assert.equal(g.saldoInicial, 500000);
});

await t('marca a fatura do cartão como paga', async () => {
  await p.click('button[data-rota="inicio"]');
  await p.waitForTimeout(400);
  const temFatura = await p.locator('[data-acao="ver-fatura"]').count();
  assert.ok(temFatura > 0, 'nenhuma fatura em aberto');
  await p.locator('[data-acao="ver-fatura"]').first().click();
  await p.waitForTimeout(300);
  await p.click('[data-acao="alternar-fatura"]');
  await p.waitForTimeout(400);
  const s = await estado();
  assert.ok(s.invoices.some((i) => i.pago));
});

await t('troca para o tema escuro', async () => {
  await p.click('[data-acao="fechar-sheet"]').catch(() => {});
  await p.waitForTimeout(200);
  await p.click('[data-acao="abrir-ajustes"]');
  await p.waitForTimeout(300);
  await p.click('[data-campo="tema"][data-valor="escuro"]');
  await p.click('[data-acao="salvar-ajustes"]');
  await p.waitForTimeout(400);
  assert.equal(await p.evaluate(() => document.documentElement.dataset.tema), 'escuro');
});

await t('os dados sobrevivem a um recarregamento', async () => {
  await p.reload();
  await p.waitForTimeout(700);
  const s = await estado();
  // 1 supermercado + 1 consultoria + 3 parcelas da geladeira; as projeções do
  // aluguel saíram junto com a pausa da recorrência, como esperado
  assert.equal(s.transactions.filter((x) => !x.deleted).length, 5);
  assert.equal(s.cards.filter((c) => !c.deleted).length, 1);
  assert.equal(s.goals.filter((g) => !g.deleted).length, 1);
  assert.ok(await p.locator('.hero .valor').isVisible());
});

await t('nenhum erro de JavaScript durante todo o percurso', () => {
  assert.deepEqual(erros, []);
});

console.log(`\n${ok} verificações passaram.\n`);
await navegador.close();
servidor.close();
