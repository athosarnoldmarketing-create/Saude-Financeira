// Testes das regras financeiras. Rodar com: node testes/teste.mjs
import assert from 'node:assert/strict';
import * as F from '../js/finance.js';
import * as U from '../js/util.js';

let ok = 0;
const t = (nome, fn) => {
  try { fn(); ok++; console.log('  ✓', nome); }
  catch (e) { console.error('  ✗', nome, '\n   ', e.message); process.exitCode = 1; }
};

const base = () => ({
  transactions: [], recurrences: [], cards: [], goals: [], invoices: [],
  categories: [{ id: 'c1', nome: 'Mercado', tipo: 'saida', orcamento: 100000, cor: '#000', icone: '🛒' }],
  settings: { saldoInicial: 500000, saldoInicialData: '2026-01-01', horizonteMeses: 3, reservaAlvoMeses: 6 },
});
const tx = (o) => ({ id: U.uid(), kind: 'tx', tipo: 'saida', valor: 1000, data: '2026-08-10', descricao: 'x', metodo: 'pix', pago: true, deleted: false, ...o });

console.log('\n== Moeda ==');
t('converte formato brasileiro', () => {
  assert.equal(U.toCents('1.234,56'), 123456);
  assert.equal(U.toCents('R$ 89,90'), 8990);
  assert.equal(U.toCents('1234.56'), 123456);
  assert.equal(U.toCents('45'), 4500);
  assert.equal(U.toCents(''), 0);
  assert.equal(U.toCents('0,05'), 5);
});
t('formata em reais', () => {
  assert.match(U.money(123456), /1\.234,56/);
  assert.equal(U.moneyPlain(8990), '89,90');
});

console.log('\n== Datas ==');
t('soma meses com clamp de fim de mês', () => {
  assert.equal(U.addMonths('2026-01-31', 1), '2026-02-28');
  assert.equal(U.addMonths('2026-08-31', 1), '2026-09-30');
  assert.equal(U.addMonths('2026-12-15', 1), '2027-01-15');
});
t('semana começa na segunda', () => {
  assert.equal(U.weekStart('2026-08-16'), '2026-08-10'); // domingo -> segunda anterior
  assert.equal(U.weekStart('2026-08-10'), '2026-08-10');
  assert.equal(U.weekEnd('2026-08-10'), '2026-08-16');
});
t('dia do mês respeita meses curtos', () => {
  assert.equal(U.dayOfMonth('2026-02', 31), '2026-02-28');
  assert.equal(U.dayOfMonth('2026-08', 5), '2026-08-05');
});

console.log('\n== Recorrências ==');
t('mensal gera uma ocorrência por mês', () => {
  const r = { frequencia: 'mensal', diaMes: 5, inicio: '2026-01-01' };
  const o = F.occurrencesBetween(r, '2026-08-01', '2026-10-31');
  assert.deepEqual(o, ['2026-08-05', '2026-09-05', '2026-10-05']);
});
t('mensal dia 31 cai no último dia dos meses curtos', () => {
  const o = F.occurrencesBetween({ frequencia: 'mensal', diaMes: 31, inicio: '2026-01-01' }, '2026-02-01', '2026-04-30');
  assert.deepEqual(o, ['2026-02-28', '2026-03-31', '2026-04-30']);
});
t('semanal respeita o dia da semana', () => {
  const o = F.occurrencesBetween({ frequencia: 'semanal', diaSemana: 1, inicio: '2026-08-01' }, '2026-08-01', '2026-08-31');
  assert.deepEqual(o, ['2026-08-03', '2026-08-10', '2026-08-17', '2026-08-24', '2026-08-31']);
});
t('respeita data de término', () => {
  const o = F.occurrencesBetween({ frequencia: 'mensal', diaMes: 10, inicio: '2026-01-01', fim: '2026-09-30' }, '2026-08-01', '2026-12-31');
  assert.deepEqual(o, ['2026-08-10', '2026-09-10']);
});
t('não duplica ocorrências já materializadas', () => {
  const s = base();
  s.recurrences.push({ id: 'r1', tipo: 'saida', valor: 150000, descricao: 'Aluguel', frequencia: 'mensal', diaMes: 5, inicio: '2026-01-01', ativo: true, deleted: false });
  const a = F.generateRecurrenceTx(s, { de: '2026-08-16', meses: 2 });
  assert.equal(a.length, 3); // ago, set, out
  s.transactions.push(...a);
  const b = F.generateRecurrenceTx(s, { de: '2026-08-16', meses: 2 });
  assert.equal(b.length, 0);
});
t('recorrência pausada não gera nada', () => {
  const s = base();
  s.recurrences.push({ id: 'r1', tipo: 'saida', valor: 1000, descricao: 'x', frequencia: 'mensal', diaMes: 5, inicio: '2026-01-01', ativo: false, deleted: false });
  assert.equal(F.generateRecurrenceTx(s, { de: '2026-08-16', meses: 2 }).length, 0);
});

console.log('\n== Cartão de crédito ==');
const card = { id: 'k1', nome: 'Cartão', diaFechamento: 25, diaVencimento: 5 };
t('compra antes do fechamento cai na fatura do mês', () => {
  const f = F.faturaDaCompra(card, '2026-08-10');
  assert.equal(f.faturaMK, '2026-08');
  assert.equal(f.dataVencimento, '2026-09-05');
});
t('compra depois do fechamento vai para a fatura seguinte', () => {
  const f = F.faturaDaCompra(card, '2026-08-26');
  assert.equal(f.faturaMK, '2026-09');
  assert.equal(f.dataVencimento, '2026-10-05');
});
t('vencimento depois do fechamento fica no mesmo mês', () => {
  const c2 = { diaFechamento: 5, diaVencimento: 15 };
  assert.equal(F.faturaDaCompra(c2, '2026-08-03').dataVencimento, '2026-08-15');
});
t('agrupa compras na fatura e soma o total', () => {
  const s = base();
  s.cards.push(card);
  s.transactions.push(
    tx({ valor: 20000, data: '2026-08-10', metodo: 'credito', cartaoId: 'k1' }),
    tx({ valor: 30000, data: '2026-08-20', metodo: 'credito', cartaoId: 'k1' }),
    tx({ valor: 10000, data: '2026-08-28', metodo: 'credito', cartaoId: 'k1' }),
  );
  const fs = F.faturas(s, '2026-01-01', '2026-12-31');
  assert.equal(fs.length, 2);
  assert.equal(fs[0].total, 50000);
  assert.equal(fs[0].dataVencimento, '2026-09-05');
  assert.equal(fs[1].total, 10000);
});
t('compra no crédito não sai do caixa na data da compra', () => {
  const s = base();
  s.cards.push(card);
  s.transactions.push(tx({ valor: 20000, data: '2026-08-10', metodo: 'credito', cartaoId: 'k1' }));
  assert.equal(F.saldoRealizado(s, '2026-08-15'), 500000);
  // vira saída prevista no vencimento
  assert.equal(F.saldoProjetado(s, '2026-09-30'), 480000);
});

console.log('\n== Parcelamento ==');
t('divide sem perder centavos', () => {
  assert.deepEqual(F.dividirParcelas(1000, 3), [334, 333, 333]);
  assert.equal(F.dividirParcelas(10000, 7).reduce((a, b) => a + b, 0), 10000);
});
t('parcelas caem em meses seguintes', () => {
  const p = F.gerarParcelas(tx({ valor: 30000, data: '2026-08-10', metodo: 'credito', cartaoId: 'k1', pago: false }), 3);
  assert.deepEqual(p.map((x) => x.data), ['2026-08-10', '2026-09-10', '2026-10-10']);
  assert.equal(p.reduce((a, b) => a + b.valor, 0), 30000);
  assert.equal(p[2].parcela.total, 3);
});

console.log('\n== Saldos e resumo ==');
t('saldo realizado ignora previstos', () => {
  const s = base();
  s.transactions.push(
    tx({ tipo: 'entrada', valor: 300000, data: '2026-08-05', pago: true }),
    tx({ tipo: 'saida', valor: 100000, data: '2026-08-06', pago: true }),
    tx({ tipo: 'saida', valor: 50000, data: '2026-08-20', pago: false }),
  );
  assert.equal(F.saldoRealizado(s, '2026-08-16'), 700000);
  assert.equal(F.saldoProjetado(s, '2026-08-31'), 650000);
});
t('resumo do mês separa realizado e previsto', () => {
  const s = base();
  s.transactions.push(
    tx({ tipo: 'entrada', valor: 300000, data: '2026-08-05', pago: true }),
    tx({ tipo: 'entrada', valor: 100000, data: '2026-08-25', pago: false }),
    tx({ tipo: 'saida', valor: 80000, data: '2026-08-06', pago: true }),
  );
  const r = F.resumoMes(s, '2026-08');
  assert.equal(r.entradas, 400000);
  assert.equal(r.entradasRealizadas, 300000);
  assert.equal(r.entradasPrevistas, 100000);
  assert.equal(r.resultado, 320000);
});
t('fluxo de caixa cobre todos os meses do intervalo', () => {
  const serie = F.fluxoCaixa(base(), '2026-06', '2026-11');
  assert.equal(serie.length, 6);
  assert.equal(serie[0].mk, '2026-06');
  assert.equal(serie[5].mk, '2026-11');
});

console.log('\n== Provisão semanal ==');
t('cinco semanas a partir da semana atual', () => {
  const s = base();
  s.transactions.push(
    tx({ tipo: 'entrada', valor: 500000, data: '2026-08-20', pago: false }),
    tx({ tipo: 'saida', valor: 120000, data: '2026-08-12', pago: false }),
  );
  const p = F.provisaoSemanal(s, { semanas: 5, hoje: '2026-08-16' });
  assert.equal(p.length, 5);
  assert.equal(p[0].inicio, '2026-08-10');
  assert.equal(p[0].saidas, 120000);
  assert.equal(p[1].entradas, 500000);
  assert.equal(p[0].atual, true);
  // saldo acumulado cresce com a entrada da segunda semana
  assert.equal(p[0].saldoFim, 500000 - 120000);
  assert.equal(p[1].saldoFim, 500000 - 120000 + 500000);
});
t('semana marca contas a pagar pendentes', () => {
  const s = base();
  s.transactions.push(tx({ valor: 9900, data: '2026-08-13', pago: false, descricao: 'Internet' }));
  const p = F.provisaoSemanal(s, { semanas: 2, hoje: '2026-08-16' });
  assert.equal(p[0].aPagar.length, 1);
  assert.equal(p[0].aPagar[0].descricao, 'Internet');
});

console.log('\n== Orçamento ==');
t('classifica estouro e atenção', () => {
  const s = base();
  s.transactions.push(tx({ valor: 110000, data: '2026-08-04', categoriaId: 'c1' }));
  const [linha] = F.orcamentoMes(s, '2026-08');
  assert.equal(linha.status, 'estourado');
  assert.equal(linha.saldo, -10000);
});
t('agrupa lançamentos sem categoria', () => {
  const s = base();
  s.transactions.push(tx({ valor: 5000, data: '2026-08-04', categoriaId: null }));
  const linhas = F.orcamentoMes(s, '2026-08');
  assert.ok(linhas.some((l) => l.categoria.id === 'sem-categoria' && l.gasto === 5000));
});

console.log('\n== Detecção de recorrências ==');
t('sugere quando a mesma origem repete em meses distintos', () => {
  const s = base();
  s.transactions.push(
    tx({ valor: 9990, data: '2026-06-08', descricao: 'Netflix' }),
    tx({ valor: 9990, data: '2026-07-08', descricao: 'Netflix' }),
    tx({ valor: 9990, data: '2026-08-08', descricao: 'netflix ' }),
  );
  const sg = F.sugestoesRecorrencia(s, { hoje: '2026-08-16' });
  assert.equal(sg.length, 1);
  assert.equal(sg[0].ocorrencias, 3);
  assert.equal(sg[0].valorMediano, 9990);
  assert.equal(sg[0].diaTipico, 8);
  assert.equal(sg[0].valorFixo, true);
});
t('não sugere o que já é recorrência', () => {
  const s = base();
  s.recurrences.push({ id: 'r1', descricao: 'Netflix', tipo: 'saida', deleted: false });
  s.transactions.push(
    tx({ valor: 9990, data: '2026-06-08', descricao: 'Netflix' }),
    tx({ valor: 9990, data: '2026-07-08', descricao: 'Netflix' }),
    tx({ valor: 9990, data: '2026-08-08', descricao: 'Netflix' }),
  );
  assert.equal(F.sugestoesRecorrencia(s, { hoje: '2026-08-16' }).length, 0);
});
t('não sugere gasto único repetido no mesmo mês', () => {
  const s = base();
  s.transactions.push(
    tx({ valor: 5000, data: '2026-08-01', descricao: 'Padaria' }),
    tx({ valor: 5000, data: '2026-08-02', descricao: 'Padaria' }),
    tx({ valor: 5000, data: '2026-08-03', descricao: 'Padaria' }),
  );
  assert.equal(F.sugestoesRecorrencia(s, { hoje: '2026-08-16' }).length, 0);
});

console.log('\n== Metas ==');
t('aporte vinculado soma na meta', () => {
  const s = base();
  s.goals.push({ id: 'g1', nome: 'Reserva', alvo: 1000000, saldoInicial: 200000, prazo: null, deleted: false });
  s.transactions.push(
    tx({ tipo: 'saida', valor: 50000, data: '2026-08-05', metaId: 'g1' }),
    tx({ tipo: 'saida', valor: 50000, data: '2026-09-05', metaId: 'g1' }),
  );
  const [m] = F.progressoMetas(s);
  assert.equal(m.acumulado, 300000);
  assert.equal(m.falta, 700000);
  assert.equal(Math.round(m.pct * 100), 30);
});

console.log('\n== Pendências ==');
t('marca atrasadas e ordena por data', () => {
  const s = base();
  s.transactions.push(
    tx({ valor: 1000, data: '2026-08-10', pago: false, descricao: 'Atrasada' }),
    tx({ valor: 2000, data: '2026-08-18', pago: false, descricao: 'A vencer' }),
    tx({ valor: 3000, data: '2026-09-30', pago: false, descricao: 'Longe' }),
  );
  const p = F.pendencias(s, { dias: 30, hoje: '2026-08-16' });
  assert.equal(p.length, 2);
  assert.equal(p[0].atrasado, true);
  assert.equal(p[1].diasRestantes, 2);
});

console.log(`\n${ok} verificações passaram.\n`);
