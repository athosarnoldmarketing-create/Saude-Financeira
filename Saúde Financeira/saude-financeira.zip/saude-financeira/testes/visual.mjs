// Confere o app em um viewport de celular e salva capturas de tela.
import { chromium, devices } from 'playwright';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const RAIZ = fileURLToPath(new URL('..', import.meta.url));
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png' };

const servidor = createServer(async (req, res) => {
  try {
    let p = decodeURIComponent(req.url.split('?')[0]);
    if (p === '/') p = '/index.html';
    const arq = join(RAIZ, normalize(p).replace(/^(\.\.[/\\])+/, ''));
    const dados = await readFile(arq);
    res.writeHead(200, { 'Content-Type': MIME[extname(arq)] || 'application/octet-stream' });
    res.end(dados);
  } catch {
    res.writeHead(404); res.end('nao encontrado');
  }
});
await new Promise((r) => servidor.listen(4321, r));

const semente = () => {
  const uid = () => 'id-' + Math.random().toString(36).slice(2, 11);
  const hoje = new Date('2026-08-16T12:00:00');
  const iso = (d) => d.toISOString().slice(0, 10);
  const dia = (mes, d) => `2026-${String(mes).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

  const cats = [
    ['Mercado', '🛒', 'saida', '#2a78d6', 180000],
    ['Moradia', '🏠', 'saida', '#eb6834', 220000],
    ['Contas de casa', '💡', 'saida', '#eda100', 65000],
    ['Transporte', '🚗', 'saida', '#e87ba4', 90000],
    ['Saúde', '🩺', 'saida', '#1baf7a', 70000],
    ['Educação', '📚', 'saida', '#4a3aa7', 130000],
    ['Alimentação fora', '🍽️', 'saida', '#008300', 45000],
    ['Lazer', '🎬', 'saida', '#e34948', 40000],
    ['Salário', '💼', 'entrada', '#1baf7a', 0],
    ['Renda extra', '✨', 'entrada', '#2a78d6', 0],
  ].map(([nome, icone, tipo, cor, orcamento]) => ({ id: uid(), kind: 'cat', nome, icone, tipo, cor, orcamento, deleted: false, updatedAt: new Date().toISOString() }));
  const c = (n) => cats.find((x) => x.nome === n).id;

  const cartao = { id: uid(), kind: 'card', nome: 'Cartão da família', diaFechamento: 25, diaVencimento: 5, limite: 800000, cor: '#4a3aa7', deleted: false, updatedAt: new Date().toISOString() };

  const tx = [];
  const add = (o) => tx.push({ id: uid(), kind: 'tx', metodo: 'pix', pago: true, deleted: false, pessoa: 'Athos', updatedAt: new Date().toISOString(), ...o });

  for (const m of [6, 7, 8]) {
    add({ tipo: 'entrada', valor: 850000, data: dia(m, 5), descricao: 'Salário Athos', categoriaId: c('Salário'), metodo: 'transferencia' });
    add({ tipo: 'entrada', valor: 620000, data: dia(m, 5), descricao: 'Salário esposa', categoriaId: c('Salário'), metodo: 'transferencia', pessoa: 'Esposa' });
    add({ tipo: 'saida', valor: 220000, data: dia(m, 10), descricao: 'Aluguel', categoriaId: c('Moradia'), metodo: 'boleto' });
    add({ tipo: 'saida', valor: 128000, data: dia(m, 8), descricao: 'Escola do Miguel', categoriaId: c('Educação'), metodo: 'boleto' });
    add({ tipo: 'saida', valor: 4990, data: dia(m, 8), descricao: 'Netflix', categoriaId: c('Lazer'), metodo: 'credito', cartaoId: cartao.id });
    add({ tipo: 'saida', valor: 18700, data: dia(m, 12), descricao: 'Energia CEMIG', categoriaId: c('Contas de casa'), metodo: 'boleto' });
    add({ tipo: 'saida', valor: 12900, data: dia(m, 15), descricao: 'Internet Vivo Fibra', categoriaId: c('Contas de casa'), metodo: 'debito' });
    for (const d of [3, 11, 19, 26]) add({ tipo: 'saida', valor: 32000 + d * 900, data: dia(m, d), descricao: 'Supermercado Bom Preço', categoriaId: c('Mercado'), metodo: 'credito', cartaoId: cartao.id });
    add({ tipo: 'saida', valor: 26000, data: dia(m, 14), descricao: 'Posto Ipiranga', categoriaId: c('Transporte'), metodo: 'credito', cartaoId: cartao.id });
    add({ tipo: 'saida', valor: 38900, data: dia(m, 20), descricao: 'Plano de saúde', categoriaId: c('Saúde'), metodo: 'debito' });
    add({ tipo: 'saida', valor: 9800, data: dia(m, 22), descricao: 'Pizzaria do bairro', categoriaId: c('Alimentação fora'), metodo: 'credito', cartaoId: cartao.id });
  }
  add({ tipo: 'entrada', valor: 180000, data: dia(8, 22), descricao: 'Consultoria avulsa', categoriaId: c('Renda extra'), pago: false, metodo: 'pix' });
  add({ tipo: 'saida', valor: 74000, data: dia(8, 28), descricao: 'IPTU parcela 6/10', categoriaId: c('Moradia'), pago: false, metodo: 'boleto' });
  add({ tipo: 'saida', valor: 15900, data: dia(8, 14), descricao: 'Farmácia', categoriaId: c('Saúde'), pago: false, metodo: 'pix' });

  const rec = [
    { tipo: 'saida', valor: 220000, descricao: 'Aluguel', categoriaId: c('Moradia'), diaMes: 10, metodo: 'boleto' },
    { tipo: 'saida', valor: 128000, descricao: 'Escola do Miguel', categoriaId: c('Educação'), diaMes: 8, metodo: 'boleto' },
    { tipo: 'saida', valor: 38900, descricao: 'Plano de saúde', categoriaId: c('Saúde'), diaMes: 20, metodo: 'debito' },
    { tipo: 'entrada', valor: 850000, descricao: 'Salário Athos', categoriaId: c('Salário'), diaMes: 5, metodo: 'transferencia' },
    { tipo: 'entrada', valor: 620000, descricao: 'Salário esposa', categoriaId: c('Salário'), diaMes: 5, metodo: 'transferencia' },
  ].map((r) => ({ id: uid(), kind: 'rec', frequencia: 'mensal', inicio: '2026-09-01', fim: null, ativo: true, deleted: false, updatedAt: new Date().toISOString(), ...r }));

  const metas = [
    { id: uid(), kind: 'goal', nome: 'Reserva de emergência', icone: '🛟', alvo: 4000000, saldoInicial: 1250000, prazo: '2027-12-31', cor: '#1baf7a', deleted: false, updatedAt: new Date().toISOString() },
    { id: uid(), kind: 'goal', nome: 'Viagem em família', icone: '✈️', alvo: 1200000, saldoInicial: 320000, prazo: '2027-01-15', cor: '#eb6834', deleted: false, updatedAt: new Date().toISOString() },
  ];

  return {
    versao: 1, transactions: tx, recurrences: rec, categories: cats, cards: [cartao], goals: metas, invoices: [],
    settings: { lar: 'Casa Aguiar', pessoas: ['Athos', 'Esposa'], saldoInicial: 940000, saldoInicialData: '2026-06-01', reservaAlvoMeses: 6, tema: 'auto', horizonteMeses: 3, updatedAt: new Date().toISOString() },
  };
};

const navegador = await chromium.launch();
const contexto = await navegador.newContext({ ...devices['iPhone 13'], locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
await contexto.addInitScript(`window.__seed = ${semente.toString()};`);
const pagina = await contexto.newPage();
const erros = [];
pagina.on('console', (m) => { if (m.type() === 'error') erros.push(m.text()); });
pagina.on('pageerror', (e) => erros.push('PAGEERROR: ' + e.message));

await pagina.goto('http://localhost:4321/index.html');
await pagina.evaluate(() => localStorage.setItem('sf.estado.v1', JSON.stringify(window.__seed())));
await pagina.reload();
await pagina.waitForTimeout(900);

const capturas = [
  ['inicio', null],
  ['lancamentos', 'button[data-rota="lancamentos"]'],
  ['fluxo', 'button[data-rota="fluxo"]'],
  ['recorrentes', 'button[data-rota="recorrentes"]'],
  ['mais', 'button[data-rota="mais"]'],
];

for (const [nome, sel] of capturas) {
  if (sel) { await pagina.click(sel); await pagina.waitForTimeout(500); }
  await pagina.screenshot({ path: `testes/tela-${nome}.png`, fullPage: true });
}

// sheet de novo lançamento
await pagina.click('button[data-rota="inicio"]');
await pagina.waitForTimeout(300);
await pagina.click('.fab');
await pagina.waitForTimeout(700);
await pagina.evaluate(() => document.activeElement?.blur());
await pagina.waitForTimeout(300);
await pagina.screenshot({ path: 'testes/tela-novo.png' });
await pagina.click('[data-acao="fechar-sheet"]');

// tema escuro
await pagina.evaluate(() => {
  const s = JSON.parse(localStorage.getItem('sf.estado.v1'));
  s.settings.tema = 'escuro';
  localStorage.setItem('sf.estado.v1', JSON.stringify(s));
});
await pagina.reload();
await pagina.waitForTimeout(900);
await pagina.screenshot({ path: 'testes/tela-escuro.png', fullPage: true });
await pagina.click('button[data-rota="fluxo"]');
await pagina.waitForTimeout(500);
await pagina.screenshot({ path: 'testes/tela-escuro-fluxo.png', fullPage: true });

console.log(erros.length ? '\nERROS NO CONSOLE:\n' + erros.join('\n') : '\nSem erros de console.');
await navegador.close();
servidor.close();
